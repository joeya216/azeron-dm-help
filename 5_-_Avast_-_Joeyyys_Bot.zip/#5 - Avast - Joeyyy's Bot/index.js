const Discord = require('discord.js');
const config = require('./config.json');
const bot = new Discord.Client();

bot.on('ready', () => {
    console.log(`${bot.user.tag} is ready using the prefix ${config.prefix}`);
});

bot.on('message', message => {
    if(message.author.bot) return;
    if(message.channel.type === "dm") {
        bot.channels.get(config.DMChannelID)
        .send(`[DM] ${message.author}: ${message.content}`);
    }
    if(message.channel.type !== "text") return;
    const args = message.content.slice(config.prefix.length).trim().split(/ +/g);
    const command = args.shift().toLowerCase();

    if(command === "dm") {
        let support = message.guild.roles.find(r=>r.name===config.DMCommandRole)
        if(!message.member.roles.has(support.id)) return reply('No permission!');
        let dmMember = message.mentions.members.first();
        if(!dmMember) return reply('Please mention a user to dm!');

        let dmMessage = args.slice(1).join(" ");
        if(!dmMessage) return reply('Please specify a message to dm!');

        dmMember.send(dmMessage);
        message.channel.send(`${message.author.tag} responded to ${dmMember}
        Response: ${dmMessage}`);

    }


    function reply(msg) {
        message.channel.send(`${message.author} - ${msg}`);
    }
});


bot.login(config.token);